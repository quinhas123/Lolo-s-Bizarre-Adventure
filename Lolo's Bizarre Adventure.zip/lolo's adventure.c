#include <stdio.h>
#include <string.h>

// Alunos: Lucas Moreira Schirmbeck e Eduardo Birkheuer da Silva
// Professora: Mariana Mendoza

// Estrutura para armazenar o registro de grava��o de progresso de um jogador
typedef struct {
int identificador;
int totalpts;
int ultimafase;
int vidas;
char nomejogador[9];
} jogador_inf;

// ================================================================= MAPAS =================================================================

// Mapas do jogo, declarados como vari�veis globais para mais f�cil acesso
    char fase2[13][13] = {
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
'P', ' ', ' ', ' ', 'E', ' ', 'P', 'P', 'P', 'E', ' ', ' ', 'P',
'P', ' ', 'C', ' ', ' ', ' ', 'P', 'P', 'P', ' ', 'C', ' ', 'P',
'P', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'P', ' ', ' ', ' ', 'P',
'P', 'A', 'A', 'A', 'A', ' ', 'A', 'A', 'A', 'A', ' ', 'A', 'P',
'P', 'A', 'A', 'A', 'A', ' ', 'A', 'A', 'A', 'A', ' ', 'A', 'P',
'P', 'T', ' ', 'P', 'P', ' ', ' ', ' ', ' ', ' ', ' ', 'A', 'P',
'P', ' ', ' ', 'P', 'P', ' ', ' ', ' ', 'P', 'P', ' ', 'A', 'P',
'P', ' ', ' ', ' ', ' ', ' ', 'P', 'P', 'P', 'P', 'P', 'A', 'P',
'P', 'E', ' ', ' ', '@', ' ', 'P', 'P', 'C', ' ', ' ', 'A', 'P',
'P', ' ', ' ', ' ', ' ', ' ', ' ', 'B', ' ', ' ', ' ', 'A', 'P',
'P', 'C', ' ', ' ', ' ', ' ', ' ', 'A', 'A', 'A', 'A', 'A', 'P',
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'
    };

    char fase1[13][13] = {
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
'P', 'P', 'P', 'P', 'P', ' ', ' ', ' ', 'B', ' ', ' ', 'P', 'P',
'P', 'P', 'C', ' ', 'B', ' ', ' ', ' ', 'P', 'C', 'P', 'P', 'P',
'P', 'P', 'P', ' ', 'P', ' ', ' ', ' ', 'P', 'P', 'P', 'P', 'P',
'P', ' ', ' ', ' ', ' ', ' ', '@', ' ', ' ', 'P', 'P', 'P', 'P',
'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P',
'P', ' ', ' ', ' ', ' ', ' ', 'T', ' ', ' ', ' ', ' ', ' ', 'P',
'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P',
'P', 'P', 'B', 'P', ' ', 'E', ' ', 'E', ' ', ' ', ' ', ' ', 'P',
'P', 'P', ' ', 'P', 'P', ' ', ' ', ' ', 'P', 'P', 'B', 'P', 'P',
'P', ' ', ' ', ' ', 'B', ' ', ' ', ' ', 'P', 'C', ' ', 'P', 'P',
'P', 'P', 'C', 'P', 'P', ' ', ' ', ' ', 'P', 'P', ' ', 'P', 'P',
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'};

char fase3[13][13] = {
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
'P', 'P', 'P', ' ', ' ', ' ', ' ', ' ', ' ', 'E', 'T', 'P', 'P',
'P', 'P', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'P', 'P', 'P',
'P', 'P', 'E', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
'P', 'P', ' ', 'P', 'P', 'E', ' ', ' ', ' ', ' ', ' ', 'P', 'P',
'P', 'P', ' ', 'P', ' ', ' ', 'P', 'P', 'P', ' ', ' ', 'P', 'P',
'P', 'P', ' ', 'P', ' ', ' ', 'C', ' ', 'P', ' ', ' ', 'P', 'P',
'P', 'P', ' ', 'P', ' ', 'C', '@', 'C', 'B', ' ', ' ', 'P', 'P',
'P', 'P', ' ', 'P', ' ', ' ', 'C', ' ', 'P', ' ', ' ', 'P', 'P',
'P', 'P', ' ', 'P', 'P', 'P', 'P', 'P', ' ', ' ', 'E', 'P', 'P',
'P', ' ', ' ', ' ', ' ', 'E', ' ', ' ', ' ', ' ', 'P', 'P', 'P',
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'};

// ============================================================ FIM DOS MAPAS =================================================================

// ======================================================= FUN��ES PARA O LOOPING DO JOGO =========================================================

// dada uma fase e duas variaveis, encontra a posi��o do lolo nessa fase
void encontra_lolo(int* x, int* y, char fase[][13]){
    int i, j;

    // Para cada posi��o da matriz, verificar se a posi��o � a de Lolo
    for(i=0; i<13; i++){
        for(j=0; j<13; j++){
            if(fase[i][j] == '@'){
                *x = i;
                *y = j;
            }
        }
    }
}

// Fun��o que faz a leitura da tecla do jogador
char mover(){
    char tecla;

    tecla=getch();

    system("cls");
return tecla;
}

// ====================================================================== Ler a��o ==========================================================================

// Nessa fun��o, � tratada a leitura da tecla do jogador. As explica��es para cada uma das situa��es em que elementos do mapa influenciam na movimenta��o de Lolo
// foi explicada apenas na "tecla w" abaixo, por�m vale para todos as teclas da fun��o.

jogador_inf acao(char tecla, int x, int y, char fase[13][13], jogador_inf jog, char* nome_arq[]){
    int cont, inimigos;

    // � verificado quantos inimigos ainda restam na fase.
    inimigos = quantos_inimigos(fase);

// =============================================================== TECLA w - ESPECIFICA��ES ===============================================================
    if(tecla=='w'){
        if(fase[x-1][y]=='P'){      // Caso o lugar para onde Lolo se mover� existir um "cora��o", ent�o o Lolo n�o se move.
            fase[x][y]='@';
        }
        else
            if((fase[x-1][y]=='B') && (fase[x-2][y]==' ')){     // Caso o lugar para onde Lolo se mover� existir um "bloco mov�vel", ent�o o Lolo se move junto com o "bloco mov�vel.
            fase[x][y] = ' ';
            fase[x-1][y] = '@';
            fase[x-2][y] = 'B';
        }
        else
            if(fase[x-1][y]=='C'){      // Caso o lugar para onde Lolo se mover� existir um "cora��o", ent�o o Lolo ganha uma vida.
            fase[x][y] = ' ';
            fase[x-1][y] = '@';
            //aumento de vida do jogador em um
            jog.vidas = jog.vidas + 1;

        }
        else
            if(fase[x-1][y]=='A'){      // Caso o lugar para onde Lolo se mover� existir "�gua", ent�o Lolo perde uma vida e zera seus pontos.
            fase[x][y] = '@';
            // diminui de vida do jogador em um e zera pontos
            jog.vidas = jog.vidas - 1;
            jog.totalpts = 0;

        }
        else
            // e vida maior que 0
            if(fase[x-1][y]=='E'){      // Caso o lugar para onde Lolo se mover� existir um "inimigo", ent�o Lolo perde uma vida e ganha um ponto.
            fase[x][y] = ' ';
            fase[x-1][y] = '@';
            // diminui de vida do jogador em um
            jog.vidas = jog.vidas - 1;
            jog.totalpts = jog.totalpts + 1;
        }
        else
            if((fase[x-1][y]=='T') && (inimigos==0)){   // Caso o lugar para onde Lolo se mover� existir "ba�" e n�o existir mais inimigos no mapa, ent�o Lolo prossegue para a pr�xima fase.
                jog.ultimafase = jog.ultimafase + 1;
            }
        else
            if((fase[x-1][y]=='T') && (inimigos!=0)){       // Caso o lugar para onde Lolo se mover� existir "ba�" e existir mais inimigos no mapa, ent�o nada acontece e o jogo continua na mesma fase.
                fase[x][y] = '@';
            }
        else{                       // Caso o lugar para onde Lolo se mover� for vazio, ent�o Lolo se move para esse lugar.
        fase[x][y] = ' ';
        fase[x-1][y] = '@';
    }
    }
// =============================================================== FIM -> TECLA w - ESPECIFICA��ES ===============================================================

// =============================================================== TECLA s - ESPECIFICA��ES ===============================================================

    if(tecla=='s'){
        if(fase[x+1][y]=='P'){
            fase[x][y]='@';
        }
        else
            if((fase[x+1][y]=='B') && (fase[x+2][y]==' ')){
            fase[x][y] = ' ';
            fase[x+1][y] = '@';
            fase[x+2][y] = 'B';
        }
        else
            if(fase[x+1][y]=='C'){
            fase[x][y] = ' ';
            fase[x+1][y] = '@';
            //aumento de vida do jogador em um
            jog.vidas = jog.vidas + 1;

        }
        else
            if(fase[x+1][y]=='A'){
            fase[x][y] = '@';
            // diminui a vida do jogador em um e zera pontos
            jog.vidas = jog.vidas - 1;
            jog.totalpts = 0;

        }
        else
            // e vida maior que 0
            if(fase[x+1][y]=='E'){
            fase[x][y] = ' ';
            fase[x+1][y] = '@';
            // diminui de vida do jogador em um
            jog.vidas = jog.vidas - 1;
            jog.totalpts = jog.totalpts + 1;
        }
        else
            if((fase[x+1][y]=='T') && (inimigos==0)){
                jog.ultimafase = jog.ultimafase + 1;
            }
        else
            if((fase[x+1][y]=='T') && (inimigos!=0)){
                fase[x][y] = '@';
            }
    else{
        fase[x][y] = ' ';
        fase[x+1][y] = '@';
    }
    }

// =============================================================== FIM -> TECLA s - ESPECIFICA��ES ===============================================================

// =============================================================== TECLA a - ESPECIFICA��ES ===============================================================

    if(tecla=='a'){
        if(fase[x][y-1]=='P'){
            fase[x][y]='@';
        }
        else
        if((fase[x][y-1]=='B') && (fase[x][y-2]==' ')){
            fase[x][y] = ' ';
            fase[x][y-1] = '@';
            fase[x][y-2] = 'B';
        }
        else
            if(fase[x][y-1]=='C'){
            fase[x][y] = ' ';
            fase[x][y-1] = '@';
            //aumento de vida do jogador em um
            jog.vidas = jog.vidas + 1;

        }
        else
            if(fase[x][y-1]=='A'){
            fase[x][y] = '@';
            // diminui a vida do jogador em um e zera pontos
            jog.vidas = jog.vidas - 1;
            jog.totalpts = 0;

        }
        else
            // e vida maior que 0
            if(fase[x][y-1]=='E'){
            fase[x][y] = ' ';
            fase[x][y-1] = '@';
            // diminui de vida do jogador em um
            jog.vidas = jog.vidas - 1;
            jog.totalpts = jog.totalpts + 1;
        }
        else
            if((fase[x][y-1]=='T') && (inimigos==0)){
                jog.ultimafase = jog.ultimafase + 1;
            }
        else
            if((fase[x][y-1]=='T') && (inimigos!=0)){
                fase[x][y] = '@';
            }
        else{
        fase[x][y] = ' ';
        fase[x][y-1] = '@';
    }
    }

// =============================================================== FIM -> TECLA w - ESPECIFICA��ES ===============================================================

// =============================================================== TECLA d - ESPECIFICA��ES ===============================================================
    if(tecla=='d'){
        if(fase[x][y+1]=='P'){
            fase[x][y]='@';
        }
        else
        if((fase[x][y+1]=='B') && (fase[x][y+2]==' ')){
            fase[x][y] = ' ';
            fase[x][y+1] = '@';
            fase[x][y+2] = 'B';
        }
        else
            if(fase[x][y+1]=='C'){
            fase[x][y] = ' ';
            fase[x][y+1] = '@';
            //aumento de vida do jogador em um
            jog.vidas = jog.vidas + 1;

        }
        else
            if(fase[x][y+1]=='A'){
            fase[x][y] = '@';
            // diminui a vida do jogador em um e zera pontos
            jog.vidas = jog.vidas - 1;
            jog.totalpts = 0;

        }
        else
            // e vida maior que 0
            if(fase[x][y+1]=='E'){
            fase[x][y] = ' ';
            fase[x][y+1] = '@';
            // diminui de vida do jogador em um
            jog.vidas = jog.vidas - 1;
            jog.totalpts = jog.totalpts + 1;
        }
        else
            if((fase[x][y+1]=='T') && (inimigos==0)){
                jog.ultimafase = jog.ultimafase + 1;
            }
        else
            if((fase[x][y+1]=='T') && (inimigos!=0)){
                fase[x][y] = '@';
            }
        else{
        fase[x][y] = ' ';
        fase[x][y+1] = '@';
    }
    }
// =============================================================== FIM -> TECLA w - ESPECIFICA��ES ===============================================================
        // Caso seja pressionado a tecla "v", ent�o � salvo o progresso do jogo
        if(tecla=='v'){
            atualiza_dados(nome_arq, jog);
        }

// Fun��o que movimenta os inimigos
movimenta_inimigos(fase);
return jog;
}
// ====================================================================== FIM DA LEITRUA DE A��O ==========================================================================


// Fun��o que, dada uma fase, imprime-a na tela
void imprime_tela(char fase[][13], jogador_inf jog){
    int i, j;

    for(i=0; i<13; i++){        // Para cada posi��o do vetor da fase, imprimir seu caract�re correspondente.
        for(j=0; j<13; j++){
            printf("%c", fase[i][j]);
        }
    printf("\n");
    }
    mostra_status(jog);     // Fun��o que imprime os status do jogador, como n�mero de vidas e pontos.
}

// Verifica��o de quantos inimigos existem na fase
int quantos_inimigos(char fase[][13]){
    int cont, i, j;

    for(i=0; i<13; i++){        // Para cada posi��o no vetor, verificar se o caract�re correspondente � um "E"; se for, somar um � vari�vel cont.
    for(j=0; j<13; j++){
        if(fase[i][j]=='E')
            cont = cont + 1;
        }
    }

return cont;
}

// Movimenta��o dos inimigos de forma aleat�ria.
void movimenta_inimigos(char fase[13][13]){
    int num, i, j;

    srand(time(NULL));
    for(i=0; i<13; i++){        // Para cada posi��o do vetor, verificar se o caract�re correspondente � um "E".
    for(j=0; j<13; j++){
        if(fase[i][j]=='E'){        // se for,
        num = 1 + (rand() % 4);     // gerar um n�mero aleat�rio entre 1 e 4

        if((num==1) && (fase[i+1][j]==' ')){        // se o n�mero aleat�rio for 1 e o espa�o correspondente ao movimento que ser� exercido pelo inimigo estiver vazio, mover o inimigo.
            fase[i+1][j]='E';
            fase[i][j]=' ';
        }
        else
        if((num==2) && (fase[i-1][j]==' ')){        // se o n�mero aleat�rio for 2 e o espa�o correspondente ao movimento que ser� exercido pelo inimigo estiver vazio, mover o inimigo.
            fase[i-1][j]='E';
            fase[i][j]=' ';
        }
        else
        if((num==3) && (fase[i][j+1]==' ')){        // se o n�mero aleat�rio for 3 e o espa�o correspondente ao movimento que ser� exercido pelo inimigo estiver vazio, mover o inimigo.
            fase[i][j+1]='E';
            fase[i][j]=' ';
        }
        else
        if((num==4) && (fase[i][j-1]==' ')){        // se o n�mero aleat�rio for 4 e o espa�o correspondente ao movimento que ser� exercido pelo inimigo estiver vazio, mover o inimigo.
            fase[i][j-1]='E';
            fase[i][j]=' ';

        }
        else{
            fase[i][j]='E';     // sen�o, n�o mover o inimigo.
        }
        }
    }
}
}

// Fun��o que imprime os status do jogador, como n�mero de vidas e pontos em tempo real.
void mostra_status(jogador_inf jog){

    printf("\nPontos: %d -", jog.totalpts);
    printf(" Vidas: %d", jog.vidas);
}

// Fun��o que verifica status espec�ficos
jogador_inf atualiza_status(jogador_inf jog){

    if(jog.totalpts==10){                     // Caso o n�mero total de pontos do jogador for equivalente a 10, ent�o o jogador ganha uma vida
        jog.vidas = jog.vidas + 1;
    }
    if(jog.vidas==0){           // Caso o n�mero total de vidas do jogador for equivalente a 0, ent�o o jogador perde todos os seus pontos mas ganha uma vida, para conseguir continuar o jogo.
        jog.totalpts = 0;
        jog.vidas = 1;
    }
return jog;
}


// ======================================================= FIM DAS FUN��ES PARA O LOOPING DO JOGO =========================================================


// ========================================================= FUN��ES DE MANIPULA��O DE ARQUIVOS =================================================================
// Fun��o que imprime todos os jogadores de um arquivo

void mostra_jogadores (char* nome_arq[]){
    jogador_inf jog;        // defini��o de vari�veis
    FILE *arq;

    // abertura do arquivo para leitura
    if( !(arq = fopen(nome_arq, "rb")) )
        printf("Nao existe nenhum jogador ainda!\n");

    else{
            //*** Imprime todos os jogadores do arquivo (enquanto n�o acabar o arquivo) ***//
        printf("*******Lista de Jogadores*******\n");
            while( !feof(arq) ){
                if(fread(&jog, sizeof(jogador_inf), 1, arq) == 1){
                    printf("* %d:\n", jog.identificador);
                    printf("* Jogador: %s\n", jog.nomejogador);
                    printf("* Total de pontos: %d - ", jog.totalpts);
                    printf("Fase %d - ", jog.ultimafase);
                    printf("%d vidas\n", jog.vidas);
                    printf("********************************\n");
            }
    }
    fclose(arq);
}
}


//*** Fun��o que adiciona um jogador em arquivos***//

jogador_inf adiciona_jogador(char* nome_arq[]){
    //*** declara��o de vairaveis ***//
    jogador_inf jog;
    FILE *arq;

    // Abertura do arquivo para acr�scimo de jogadores //
    if( !(arq = fopen(nome_arq, "ab+")) )
        printf("Erro na criacao!\n");

    // Acr�scimo dos dados do novo jogador //
    else{
        fflush(stdin);
        printf("Nome do jogador: ");        // Nome do novo jogador (informado pelo jogador)
        fgets(jog.nomejogador, 8, stdin);

        // Uso de uma fun��o que auxilia na identifica��o do identificador do novo jogador
        jog.identificador = identificador_jogador(nome_arq, arq);
        jog.totalpts = 0;
        jog.ultimafase = 1;                                            // Informa��es de jogo uniformes para todo novo jogador (numero inicial de fatores de jogo)
        jog.vidas = 1;

        fwrite(&jog, sizeof(jogador_inf), 1, arq);

        fclose(arq);
    }
return jog;
}


// Fun��o para informar qual � o identificador de um novo jogador //

int identificador_jogador(char* nome_arq[], FILE* arq){

    // Declara��o de vari�veis
    int contador=0;
    jogador_inf jog;

    // Enquanto o arquivo n�o acabar
    while(!feof(arq)){

        // Contar um para cada jogador existente
        if(fread(&jog, sizeof(jogador_inf), 1, arq) == 1){
        contador = contador + 1;
        }
    }
// Devolver o n�mero de jogadores existentes mais um (correspondente ao identificador do novo jogador)
contador = contador + 1;
return contador;
}


// Fun��o para salvar o progresso de um jogador (atualiza��o de dados) //

void atualiza_dados(char* nome_arq[], jogador_inf jog){

    // Declara��o de vari�veis
    FILE *arq;
    int cont=0, encontrado=0;
    jogador_inf jog1;

    // Abertura de arquivo para leitura e escritura
    if( !(arq = fopen(nome_arq, "r+b")) )
    printf("Erro na criacao\n");

    else{

        // Enquanto n�o acabar o arquivo e n�o for encontrado o identificador do jogador no arquivo
        while( !feof(arq) && !encontrado ){

        // Ler um jogador no arquivo
        if(fread(&jog1, sizeof(jogador_inf), 1, arq) == 1){

                // Caso o identificador do jogador seja igual com o identificador do jogador no arquivo bin�rio,
                if(jog1.identificador == jog.identificador){

                    // Sobreescrever as informa��es do jogador com as informa��es referentes ao progresso do jogador at� o ponto onde o jogo est� sendo salvo
                    fseek(arq, cont*sizeof(jogador_inf), SEEK_SET);
                    if(fwrite(&jog, sizeof(jogador_inf), 1, arq) != 1){
                    printf("\nErro de gravacao!!!\n");
                    }
                encontrado=1;
                }
        }
        cont = cont + 1;
    }
    fclose(arq);
}
}


// Fun��o para a escolha de um dos jogadores do arquivo bin�rio //
jogador_inf escolha_save(char* nome_arq[]){

    // Declara��o de vari�veis
    FILE *arq;
    int id, cont;
    jogador_inf jogadorauxilio;

    // Leitura do identificador correspondente ao jogo que o jogador quer carregar
    cont = quantos_jogadores(nome_arq);

    do{
    printf("Digite o identificador do jogo que queres carregar! ");
    scanf("%d", &id);
    if(id<1 || id>cont){
        printf("Identificador invalido!\n");
    }
    }while(id<1 || id>cont);

    // Abertura do arquivo para leitura
    if( !(arq = fopen(nome_arq, "rb")) )
        printf("Tente novamente!\n");

    else{

        // Enquanto o arquivo n�o acabar
        while( !feof(arq) ){

            // Ler jogador
            if(fread(&jogadorauxilio, sizeof(jogador_inf), 1, arq) == 1){

                // Se o identificador lido for igual ao identificador do jogador no arquivo bin�rio, � retornado as informa��es desse jogador
                if(id == jogadorauxilio.identificador){
                    return jogadorauxilio;
                }
            }
            }
            fclose(arq);
            }
}


// Fun��o que interpreta a escolha no menu do jogador
void destinos (char caracter, jogador_inf* jog){
    char nome_arq[15] = "saveslolo"; // Nome do arquivo bin�rio dos jogadores

    // Caso o jogador escolha "Novo Jogo"
    if (caracter == 'N'){
        system("cls");

        // � adicionado um novo jogador ao arquivo bin�rio e � salvo as informa��es desse jogador na vari�vel "jogador"
        *jog = adiciona_jogador(nome_arq);
    }
    else

        // Caso o jogador escolha "Carregar Jogo"
        if(caracter == 'C'){
            system("cls");

            // � impresso a lista de jogadores do arquivo bin�rio e � salvo na vari�vel "jogador" o jogo escolhido para carregamento
            mostra_jogadores(nome_arq);
            *jog = escolha_save(nome_arq);
        }
        else

            // Caso seja escolhido "Mostrar Cr�ditos"
            if(caracter == 'M'){
                system("cls");
                // � impresso os desenvolvedores do jogo
                printf("Desenvolvedores do codigo: \nLucas Moreira Schirmbeck (00324412)\nEduardo Birkheuer da Silva (00324300)\n");
            }
            else

                // Caso seja escolhido "Sair"
                if(caracter == 'S'){

                    // � impresso uma mensagem de despedida
                    printf("\nEncerrando o jogo, ateh a proxima!");
                }

}


// Fun��o que l� quantos jogadores existem no arquivo bin�rio de jogos salvos
int quantos_jogadores(char* nome_arq[]){
    FILE *arq;      // declara��o de vari�veis
    int contador;
    jogador_inf jog;

    // abertura do arquivo para leitura
    if( !(arq = fopen(nome_arq, "rb")) )
        printf("Nao existe nenhum jogador ainda!\n");

    else{
    while(!feof(arq)){
     if(fread(&jog, sizeof(jogador_inf), 1, arq)){
        contador = contador + 1;
     }
    }
    return contador;
    fclose(arq);
    }
}

// ====================================================== FIM DAS FUN��ES DE MANIPULA��O DE ARQUIVOS ==============================================================



// ===================================================== FUN��ES DE INTERFACE E NAVEGA��O NA INTERFACE =================================================================

// Fun��o para a impress�o de asteriscos
void asterisco(){
    char i;
    for(i=0; i<67; i++){
        printf("*");
    }
    }

// Fun��o para imprimir o "design" da interface
void interface(){
    asterisco();
    printf("\n     _        _     _    _   __          __      ___       __   __\n|   | | |    | |'  |_   |_| |  |  |  |  |_  || |  |  |  | |__| |_\n|__ |_| |__  |_|    _|  | | |__/  |__/  |__ | |   |  |__| | |  |__\n\n");
    asterisco();

    printf("\n(N) - Novo Jogo\n");
    printf("(C) - Carregar Jogo\n");
    printf("(M) - Mostrar Creditos\n");
    printf("(S) - Sair\n");
    printf("\nINSTRUCOES:\nw - Mover Lolo para cima\na - Mover Lolo para a esquerda\ns - Mover Lolo para baixo\nd - Mover Lolo para a direita\nv - Salvar progresso\n");
    printf("\nDigite uma opcao de menu: ");
}

// Leitura e valida��o de car�cteres de sele��o
char le_letra(){

    // Declara��o de vari�veis
    char x;

    // Enquanto o jogador n�o digitar um dos car�cteres especificados, repetir
    do{
        // Leitura do car�cter
        scanf(" %c", &x);
        if(x!='N' && x!='M' && x!='C' && x!='S')
            printf("Opcao invalida: ");
        }while(x!='N' && x!='M' && x!='C' && x!='S');

// Retorna o car�cter especificado
return x;
}

// ================================================== FIM DAS FUN��ES DE INTERFACE E NAVEGA��O NA INTERFACE =============================================================


// =============================================================== IMPLEMENTA��O NA MAIN ===============================================================================
int main(){
    int x, y;
    char tecla;

    // Declara��o de vari�veis importantes para a main

    jogador_inf jogador;    // Informa��es do jogador em quest�o
    char nome_arq[15] = "saveslolo"; // Nome do arquivo bin�rio dos jogadores
    char escolha;       // Car�cter que grava a escolha no menu do jogador

    // Impress�o da interface
    interface();

    // Leitura e valida��o da escolha do jogador
    escolha = le_letra();

    // Destinos da leitura da escolha
    destinos(escolha, &jogador);

    // Se a �ltima fase do jogador carregado for igual a 1, ent�o a fase 1 � carregada. O looping � igual para todas as fases. Sendo assim, � feito a explica��o do looping apenas na primeira fase.
    if(jogador.ultimafase==1){

    do{                             // Enquanto a ultima fase n�o for igual � segunda - atualiza��o feita ao terminar a primeira fase - repretir o looping de jogo.
    encontra_lolo(&x, &y, fase1);       // Encontrar Lolo na fase.

    imprime_tela(fase1, jogador);           //Imprimir o mapa na tela.

    tecla=mover();      // Ler a tecla do jogador.

    jogador = acao(tecla, x, y, fase1, jogador, nome_arq);      // Tratar a��o do jogador.

    jogador = atualiza_status(jogador);     // Atualizar status do jogador para ser impresso em tempo real.

    }while(jogador.ultimafase!=2);

    }

    atualiza_dados(nome_arq, jogador);

    if(jogador.ultimafase==2){

    do{
    encontra_lolo(&x, &y, fase2);

    imprime_tela(fase2, jogador);

    tecla=mover();

    jogador = acao(tecla, x, y, fase2, jogador, nome_arq);

    jogador= atualiza_status(jogador);

    }while(jogador.ultimafase!=3);

    }

    atualiza_dados(nome_arq, jogador);

    if(jogador.ultimafase==3){

    do{
    encontra_lolo(&x, &y, fase3);

    imprime_tela(fase3, jogador);

    tecla=mover();

    jogador = acao(tecla, x, y, fase3, jogador, nome_arq);

    jogador= atualiza_status(jogador);

    }while(jogador.ultimafase!=4);

    }

    if (jogador.ultimafase==4){     // Caso o jogador acaba todas as fases, � impresso uma mensagem de congratula��es ao jogador e � salvo o progresso do jogador para posterior visualiza��o.
    printf("Fim de jogo! Parab�ns, voce ganhou! Os status podem ser checados na lista de carregamento!");
    atualiza_dados(nome_arq, jogador);
    }

return 0;
}

// ======================================================= FIM DA IMPLEMENTA��O NA MAIN =========================================================================
